//
//  DrawingVC.swift
//  handwriting_recognizer
//
//  Created by Aakanksha Patel on 11/14/19.
//  Copyright © 2019 Aakanksha Patel. All rights reserved.
//

import UIKit

class DrawingVC: UIViewController {

    @IBOutlet weak var drawImageView: UIImageView!
    
    @IBOutlet weak var predictionLabel: UILabel!
    
    var lastPoint = CGPoint.zero
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        drawImageView.image = nil
        if let touch = touches.first {
            lastPoint = touch.location(in: drawImageView)
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first{
            let currPoint = touch.location(in: drawImageView)
            drawLine(fromPoint: lastPoint, toPoint: currPoint)
            
            lastPoint = currPoint
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    func drawLine(fromPoint: CGPoint, toPoint: CGPoint){
        UIGraphicsBeginImageContext(drawImageView.frame.size)
        let context = UIGraphicsGetCurrentContext()
        
        drawImageView.image?.draw(in:  CGRect(x:0, y:0, width: drawImageView.frame.size.width, height: drawImageView.frame.size.height))
        
        context?.move(to: CGPoint(x: fromPoint.x, y: fromPoint.y))
        context?.addLine(to: CGPoint(x:toPoint.x, y:toPoint.y))
        
        context?.setLineCap(.round)
        context?.setLineWidth(10.0)
        context?.setStrokeColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))
        context?.setBlendMode(.normal)
        context?.strokePath()
        
        drawImageView.image = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
    }
    
    @IBOutlet weak var predictBtnWasPressed: UIButton!
    
}

